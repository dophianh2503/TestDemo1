//
//  ViewController.swift
//  Calculator
//
//  Created by PAnh on 11/5/20.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtSoA: UITextField!
    
    
    @IBOutlet weak var txtSoB: UITextField!
    
    
    @IBAction func btnCong(_ sender: Any) {
        if(txtSoA.text! == "" || txtSoB.text! == ""){
            txtKQ.text! = "Bạn phải nhập đủ số"
        }
        else{
            let a: String = txtSoA.text!
            let a1 = Int(a)
            let b: String = txtSoB.text!
            let b1 = Int(b)
            let cong:Int
            cong = a1! + b1!
            txtKQ.text = String(cong)
        }
        //        txtKQ.text! = String(Cong())
    }
    @IBAction func btnTru(_ sender: Any) {
        if(txtSoA.text! == "" || txtSoB.text! == ""){
            txtKQ.text! = "Bạn phải nhập đủ số"
        }
        else{
            let a: String = txtSoA.text!
            let a1 = Int(a)
            let b: String = txtSoB.text!
            let b1 = Int(b)
            let tru:Int
            tru = a1! - b1!
            txtKQ.text = String(tru)
        }
        //        txtKQ.text! = String(Tru())
    }
    
    
    @IBAction func btnNhan(_ sender: Any) {
        if(txtSoA.text! == "" || txtSoB.text! == ""){
            txtKQ.text! = "Bạn phải nhập đủ số"
        }
        else{
            let a: String = txtSoA.text!
            let a1 = Int(a)
            let b: String = txtSoB.text!
            let b1 = Int(b)
            let nhan:Int
            nhan = a1! * b1!
            txtKQ.text = String(nhan)
        }
        //        txtKQ.text! = String(Nhan())
    }
    
    @IBAction func btnChia(_ sender: Any) {
        if(txtSoA.text! == "" || txtSoB.text! == ""){
            txtKQ.text! = "Bạn phải nhập đủ số"
        }
        else{
            let a: String = txtSoA.text!
            let a1 = Int(a)
    
            let b: String = txtSoB.text!
            let b1 = Int(b)
            let chia:Double
            if(b1 == 0){
                txtKQ.text = "Mẫu số phải lớn hơn không"
            }
            else{
                chia = Double(a1! / b1!)
                txtKQ.text = String(chia)
            }
        }
        
        //        txtKQ.text! = String(Chia())
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    public func Cong()->Int{
        if(txtSoA.text! == "" || txtSoB.text! == ""){
            txtKQ.text! = "Bạn phải nhập đủ số"
        }
        let a: String = txtSoA.text!
        let a1 = Int(a)
        let b: String = txtSoB.text!
        let b1 = Int(b)
        let cong:Int
        cong = a1! + b1!
        return cong
    }
    public func Tru()->Int{
        let a: String = txtSoA.text!
        let a1 = Int(a)
        
        let b: String = txtSoB.text!
        let b1 = Int(b)
        let tru:Int
        tru = a1! - b1!
        return tru
    }
    public func Nhan()->Int{
        let a: String = txtSoA.text!
        let a1 = Int(a)
        
        let b: String = txtSoB.text!
        let b1 = Int(b)
        let nhan:Int
        nhan = a1! * b1!
        return nhan
    }
    //        public func Chia()->Double{
    //            let a: String = txtSoA.text!
    //            let a1 = Double(a)
    //
    //            let b: String = txtSoB.text!
    //            let b1 = Double(b)
    //            let chia:Double
    //            if(b1 == 0 ){
    //                txtKQ.text! = "Mẫu số phải lớn hơn không"
    //            }
    //            else{
    //                chia = a1! / b1!
    //            }
    //            return 0
    //        }
    @IBOutlet weak var txtKQ: UITextField!
    
}

